"""
loop.py — Loop estilo Karpathy 'autoresearch' para trading:
  1 archivo mutable (strategy.py) · 1 harness fijo (prepare.py) · 1 métrica escalar · presupuesto fijo · keep/revert · ledger.

  python loop.py baseline              # primera corrida (registra baseline)
  python loop.py run "descripción"     # evalúa strategy.py actual; keep si mejora, si no REVIERTE
  python loop.py auto 20               # 20 iteraciones automáticas de mutación de PARAMS (sin LLM)
  python loop.py final                 # VAULT: una sola vez, con la mejor estrategia
Con un agente (Claude Code): apúntalo a program.md; él edita strategy.py y llama `loop.py run`.
"""
import os, sys, ast, re, json, csv, time, shutil, random, subprocess
LEDGER, SNAP, MIN_DELTA = "results.tsv", "snapshots", 0.0005
COLS = ["trial", "score", "vol_skill", "exp_bss", "dir_bss", "best_net_sharpe", "seconds", "status", "description"]


def read_ledger():
    if not os.path.exists(LEDGER):
        return []
    with open(LEDGER) as f:
        return list(csv.DictReader(f, delimiter="\t"))


def append(row):
    new = not os.path.exists(LEDGER)
    with open(LEDGER, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=COLS, delimiter="\t", lineterminator="\n")
        if new: w.writeheader()
        w.writerow(row)


def best():
    keeps = [r for r in read_ledger() if r["status"] == "keep"]
    return max(keeps, key=lambda r: float(r["score"])) if keeps else None


def evaluate_once():
    env = dict(os.environ, VOL_N_TRIALS=str(len(read_ledger()) + 1))
    p = subprocess.run([sys.executable, "prepare.py", "dev"], capture_output=True, text=True, env=env)
    open("run.log", "w").write(p.stdout + "\n" + p.stderr)
    line = [l for l in p.stdout.splitlines() if l.startswith("SUMMARY_JSON:")]
    return json.loads(line[0][13:]) if line else None


def run(desc):
    os.makedirs(SNAP, exist_ok=True)
    n = len(read_ledger()) + 1
    s = evaluate_once()
    if s is None:
        append(dict(trial=n, score=0, vol_skill=0, exp_bss=0, dir_bss=0, best_net_sharpe=0, seconds=0,
                    status="crash", description=desc + " | ver run.log"))
        print("CRASH (ver run.log)"); revert(); return
    b = best()
    ok = (b is None) or (s["score"] > float(b["score"]) + MIN_DELTA)
    append(dict(trial=n, score=f"{s['score']:.5f}", vol_skill=f"{s['vol_skill']:.5f}", exp_bss=f"{s['exp_bss']:.5f}",
                dir_bss=f"{s['dir_bss']:.5f}", best_net_sharpe=f"{s['best_net_sharpe']:.3f}",
                seconds=f"{s['seconds']:.0f}", status="keep" if ok else "discard", description=desc))
    if ok:
        shutil.copy("strategy.py", f"{SNAP}/strategy_best.py")
        print(f"KEEP  score={s['score']:.5f}  ({desc})")
    else:
        print(f"DISCARD score={s['score']:.5f} <= best {b['score']}  ({desc})"); revert()


def revert():
    if os.path.exists(f"{SNAP}/strategy_best.py"):
        shutil.copy(f"{SNAP}/strategy_best.py", "strategy.py")


def auto(n):
    import importlib.util
    for i in range(n):
        spec = importlib.util.spec_from_file_location("strategy_probe", "strategy.py")
        m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        params = dict(m.PARAMS); k = random.choice(list(m.SPACE))
        params[k] = random.choice([v for v in m.SPACE[k] if v != params[k]] or m.SPACE[k])
        src = open("strategy.py").read()
        src = re.sub(r"^PARAMS = .*$", "PARAMS = " + repr(params), src, count=1, flags=re.M)
        open("strategy.py", "w").write(src)
        print(f"[auto {i+1}/{n}] {k} -> {params[k]}")
        run(f"auto: {k}={params[k]}")


def final(force=False):
    if os.path.exists("vault_runs.log") and not force:
        sys.exit("El vault YA se usó. Repetirlo lo invalida (data snooping). Usa --force solo si lo entiendes.")
    revert()
    p = subprocess.run([sys.executable, "prepare.py", "vault"], text=True, capture_output=True,
                       env=dict(os.environ, VOL_N_TRIALS=str(len(read_ledger()) + 1)))
    print(p.stdout, p.stderr[-2000:])
    open("vault_runs.log", "a").write(time.strftime("%F %T") + " vault ejecutado\n")


if __name__ == "__main__":
    c = sys.argv[1]
    if c == "baseline": run("baseline")
    elif c == "run": run(sys.argv[2] if len(sys.argv) > 2 else "sin descripción")
    elif c == "auto": auto(int(sys.argv[2]) if len(sys.argv) > 2 else 10)
    elif c == "final": final("--force" in sys.argv)
